%Copyright 2013 The MathWorks, Inc
clear all;close all;clc;sAnt = lowProfileArray('FrequencyRange',[2e9 4e9],'ViewArray',true);