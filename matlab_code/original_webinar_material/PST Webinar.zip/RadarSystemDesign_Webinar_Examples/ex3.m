%Copyright 2013 The MathWorks, Inc
clear all;close all;clc;rangeDopplerStreamExample